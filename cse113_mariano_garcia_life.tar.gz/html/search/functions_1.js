var searchData=
[
  ['fill_5fcell_5fin_5flife',['fill_cell_in_life',['../life_8c.html#a6ff06345a3dfb461606997897dad481c',1,'fill_cell_in_life(unsigned char **life, int rows, int cols, Cell cell, unsigned char value):&#160;life.c'],['../life_8h.html#a6ff06345a3dfb461606997897dad481c',1,'fill_cell_in_life(unsigned char **life, int rows, int cols, Cell cell, unsigned char value):&#160;life.c']]],
  ['free_5flife',['free_life',['../life_8c.html#a84e025a3aaf8449bf5a8cded80b6027a',1,'free_life(unsigned char ***plife, int rows, int cols):&#160;life.c'],['../life_8h.html#a84e025a3aaf8449bf5a8cded80b6027a',1,'free_life(unsigned char ***plife, int rows, int cols):&#160;life.c']]]
];
