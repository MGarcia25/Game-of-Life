var searchData=
[
  ['reset_5flife',['reset_life',['../life_8c.html#acafd66237c1bb0c31d0b0e2ee27aac2c',1,'reset_life(unsigned char **life, int rows, int cols):&#160;life.c'],['../life_8h.html#acafd66237c1bb0c31d0b0e2ee27aac2c',1,'reset_life(unsigned char **life, int rows, int cols):&#160;life.c']]]
];
