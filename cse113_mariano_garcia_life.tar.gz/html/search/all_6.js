var searchData=
[
  ['init_5flife_5ffrom_5ffile',['init_life_from_file',['../life_8c.html#ab501239ea6a696cc126806a771af05db',1,'init_life_from_file(unsigned char **life, int rows, int cols, char edge, Cell cur, const char *filename):&#160;life.c'],['../life_8h.html#ab501239ea6a696cc126806a771af05db',1,'init_life_from_file(unsigned char **life, int rows, int cols, char edge, Cell cur, const char *filename):&#160;life.c']]],
  ['init_5fsdl_5finfo',['init_sdl_info',['../sdl_8h.html#a1094292af49bb6c4abf089ab73a79bb9',1,'sdl.h']]]
];
