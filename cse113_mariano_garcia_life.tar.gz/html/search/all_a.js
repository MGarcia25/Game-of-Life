var searchData=
[
  ['process_5fgeneration',['process_generation',['../life_8c.html#a49287d321816233403f41d9c2ec7766e',1,'process_generation(unsigned char **lifeA, int rows, int cols, unsigned char **lifeB, char edge):&#160;life.c'],['../life_8h.html#a49287d321816233403f41d9c2ec7766e',1,'process_generation(unsigned char **lifeA, int rows, int cols, unsigned char **lifeB, char edge):&#160;life.c']]]
];
