var searchData=
[
  ['col',['col',['../structCell.html#a09e2f07cb87b7ae5898be20927cf28d1',1,'Cell']]],
  ['color',['color',['../structsdl__info__t.html#a793e548fc0386a76cdee71647bd096d4',1,'sdl_info_t']]]
];
