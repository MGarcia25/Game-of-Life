var searchData=
[
  ['alloc_5flife',['alloc_life',['../life_8c.html#a58a4341e180ef469edb74517cb716174',1,'alloc_life(int rows, int cols):&#160;life.c'],['../life_8h.html#a58a4341e180ef469edb74517cb716174',1,'alloc_life(int rows, int cols):&#160;life.c']]]
];
