var searchData=
[
  ['get_5falive_5fnbrs',['get_alive_nbrs',['../life_8h.html#a34d369c081ea3392c73662c598454891',1,'life.h']]],
  ['get_5falive_5fnum',['get_alive_NUM',['../life_8c.html#a334ae4f270d893eedf8299ce668bb563',1,'life.c']]],
  ['get_5fnext_5fcell',['get_next_cell',['../life_8c.html#a0f288d82953d88e203736b12f49c9d91',1,'get_next_cell(int rows, int cols, char edge, Cell cur, Cell dist):&#160;life.c'],['../life_8h.html#a0f288d82953d88e203736b12f49c9d91',1,'get_next_cell(int rows, int cols, char edge, Cell cur, Cell dist):&#160;life.c']]]
];
