var searchData=
[
  ['num',['NUM',['../life_8c.html#aaf0952059602752258dccaa015d7b54a',1,'life.c']]]
];
